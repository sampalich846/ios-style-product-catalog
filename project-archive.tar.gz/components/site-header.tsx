"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";

export function SiteHeader() {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const handleToggle = useCallback(() => {
    setMenuOpen((prev) => !prev);
  }, []);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    }

    if (menuOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [menuOpen]);

  return (
    <header
      className="font-pt-sans"
      style={{
        fontFamily: "var(--font-pt-sans, 'PT Sans', sans-serif)",
        backgroundColor: "#950a2b",
      }}
    >
      <div className="flex items-center justify-between py-[15px] relative">
        {/* Left: burger */}
        <div className="pl-5 relative" ref={menuRef}>
          <button
            type="button"
            className="flex items-center justify-center"
            style={{ width: 20, height: 17 }}
            onClick={handleToggle}
            aria-label={menuOpen ? "Закрыть меню" : "Открыть меню"}
            aria-expanded={menuOpen}
          >
            <svg width="20" height="17" viewBox="0 0 17 14" fill="#fff">
              <path
                fillRule="evenodd"
                d="M.05 1.086C.05.486.538 0 1.138 0h13.828a1.086 1.086 0 010 2.172H1.137c-.6 0-1.086-.487-1.086-1.086zm0 5.428c0-.6.487-1.086 1.087-1.086h13.828a1.086 1.086 0 110 2.172H1.137C.537 7.6.05 7.114.05 6.514zm1.087 4.343a1.086 1.086 0 000 2.171h13.828a1.086 1.086 0 000-2.171H1.137z"
                clipRule="evenodd"
              />
            </svg>
          </button>

          <div
            className={`absolute top-full left-0 mt-2 w-56 rounded-xl border bg-white shadow-lg z-50 transition-all duration-300 ease-out origin-top-left ${
              menuOpen
                ? "opacity-100 scale-100 visible"
                : "opacity-0 scale-95 invisible pointer-events-none"
            }`}
          >
            <nav className="py-2">
              <Link
                href="/contacts"
                className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#A70230] transition-colors"
                onClick={() => setMenuOpen(false)}
              >
                Где купить
              </Link>
              <Link
                href="/about"
                className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#A70230] transition-colors"
                onClick={() => setMenuOpen(false)}
              >
                О компании
              </Link>
              <Link
                href="/privacy"
                className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-100 hover:text-[#A70230] transition-colors"
                onClick={() => setMenuOpen(false)}
              >
                Политика конфиденциальности
              </Link>
            </nav>
          </div>
        </div>

        {/* Center: logo */}
        <Link
          href="/"
          className="absolute left-1/2 -translate-x-1/2"
          style={{ lineHeight: 0 }}
        >
          <img
            src="/main-logo.svg"
            alt="Логотип"
            className="h-8 w-auto object-contain"
          />
        </Link>

        {/* Right: favorites */}
        <div className="pr-5">
          <Link
            href="/?tab=favorites"
            className="relative flex items-center"
            aria-label="Избранное"
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 25"
              fill="#fff"
              stroke="#fff"
              strokeWidth={1.5}
            >
              <path d="M12 20.81l-1.392-1.208C5.664 15.326 2.4 12.497 2.4 9.045c0-2.829 2.323-5.035 5.28-5.035 1.67 0 3.274.742 4.32 1.904 1.046-1.162 2.65-1.904 4.32-1.904 2.957 0 5.28 2.206 5.28 5.035 0 3.452-3.264 6.28-8.208 10.557L12 20.81z" />
            </svg>
            <span
              className="absolute flex items-center justify-center rounded-full bg-white text-[#950a2b] font-bold"
              style={{
                width: 17,
                height: 17,
                fontSize: 10,
                lineHeight: "0.9",
                marginLeft: -3,
                marginTop: -5,
                top: 0,
                right: -8,
              }}
            >
              0
            </span>
          </Link>
        </div>
      </div>
    </header>
  );
}
