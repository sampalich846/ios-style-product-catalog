import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "У Палыча — каталог кондитерских изделий",
    short_name: "У Палыча",
    description:
      "Торты, пирожные, пироги, мороженое и заморозка от ТМ «У Палыча»",
    start_url: "/",
    display: "standalone",
    background_color: "#A70230",
    theme_color: "#A70230",
    orientation: "portrait",
    icons: [
      { src: "/icon.svg", sizes: "any", type: "image/svg+xml" },
      { src: "/icon.svg", sizes: "180x180", type: "image/svg+xml" },
    ],
  };
}
