export default function ProductLoading() {
  return (
    <div className="h-dvh bg-white flex flex-col">
      <div className="relative flex-1 overflow-y-auto ios-scroll">
        {/* Hero image skeleton */}
        <div className="relative h-[50vh] min-h-[320px] bg-muted animate-pulse">
          {/* Back button skeleton */}
          <div className="absolute top-12 left-4 h-9 w-9 rounded-full bg-muted-foreground/10" />
          {/* Favorite button skeleton */}
          <div className="absolute top-12 right-4 h-9 w-9 rounded-full bg-muted-foreground/10" />
        </div>

        {/* Content skeleton */}
        <div className="px-5 pt-5 pb-8 space-y-5">
          {/* Title skeleton */}
          <div className="h-9 w-3/4 rounded-lg bg-muted animate-pulse" />

          {/* Weight badge skeleton */}
          <div className="h-7 w-20 rounded-full bg-muted animate-pulse" />

          {/* Description skeleton */}
          <div className="space-y-3">
            <div className="h-4 w-16 rounded bg-muted animate-pulse" />
            <div className="h-4 w-full rounded bg-muted animate-pulse" />
            <div className="h-4 w-5/6 rounded bg-muted animate-pulse" />
            <div className="h-4 w-4/6 rounded bg-muted animate-pulse" />
          </div>

          {/* Ingredients skeleton */}
          <div className="space-y-3">
            <div className="h-4 w-12 rounded bg-muted animate-pulse" />
            <div className="h-4 w-full rounded bg-muted animate-pulse" />
            <div className="h-4 w-5/6 rounded bg-muted animate-pulse" />
            <div className="h-4 w-3/4 rounded bg-muted animate-pulse" />
            <div className="h-4 w-2/3 rounded bg-muted animate-pulse" />
          </div>
        </div>
      </div>

      {/* Где купить button skeleton */}
      <div className="bg-white px-5 pb-8 pt-4">
        <div className="w-full h-14 rounded-2xl bg-muted animate-pulse" />
      </div>
    </div>
  );
}
