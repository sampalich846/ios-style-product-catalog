"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Heart } from "lucide-react";
import { CatalogPage } from "@/components/catalog-page";
import { ContactsPage } from "@/components/contacts-page";
import { ProductCard } from "@/components/product-card";
import { TabBar } from "@/components/tab-bar";
import { mockProducts, mockStores } from "@/lib/mock-data";
import { getFavoriteIds, toggleFavoriteId } from "@/lib/favorites";
import type { TabId } from "@/components/tab-bar";

export default function ContactsRoute() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<TabId>("contacts");
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(() => {
    if (typeof window !== "undefined") {
      return new Set(getFavoriteIds());
    }
    return new Set();
  });

  const handleTabChange = useCallback((tab: TabId) => {
    setActiveTab(tab);
  }, []);

  const handleToggleFavorite = useCallback((id: string) => {
    toggleFavoriteId(id);
    setFavoriteIds(new Set(getFavoriteIds()));
  }, []);

  return (
    <div className="flex flex-col h-dvh bg-white">
      <div className="flex-1 overflow-hidden">
        {activeTab === "catalog" && (
          <div key="catalog" className="h-full animate-in fade-in duration-300">
            <CatalogPage
              products={mockProducts}
              favoriteIds={favoriteIds}
              onToggleFavorite={handleToggleFavorite}
            />
          </div>
        )}
        {activeTab === "favorites" && (
          <div
            key="favorites"
            className="h-full animate-in fade-in slide-in-from-bottom-4 duration-400"
          >
            <FavoritesPage
              favoriteIds={favoriteIds}
              onToggleFavorite={handleToggleFavorite}
            />
          </div>
        )}
        {activeTab === "contacts" && (
          <div
            key="contacts"
            className="h-full animate-in fade-in slide-in-from-bottom-4 duration-400"
          >
            <ContactsPage stores={mockStores} onBack={() => router.push("/")} />
          </div>
        )}
      </div>
      <TabBar activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  );
}

function FavoritesPage({
  favoriteIds,
  onToggleFavorite,
}: {
  favoriteIds: Set<string>;
  onToggleFavorite: (id: string) => void;
}) {
  const favoriteProducts = mockProducts.filter((p) => favoriteIds.has(p.id));

  return (
    <div className="h-full flex flex-col overflow-y-auto ios-scroll">
      <div className="px-5 pt-14 pb-2">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">
          Избранное
        </h1>
      </div>
      {favoriteProducts.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted mb-3">
            <Heart className="h-5 w-5 fill-none" />
          </div>
          <p className="text-sm">Нет избранных товаров</p>
          <p className="text-xs text-muted-foreground/60 mt-1">
            Нажмите на сердечко на карточке товара, чтобы добавить его сюда
          </p>
        </div>
      ) : (
        <div className="px-5 pb-8 space-y-4">
          {favoriteProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              isFavorite={true}
              onToggleFavorite={onToggleFavorite}
            />
          ))}
        </div>
      )}
    </div>
  );
}
