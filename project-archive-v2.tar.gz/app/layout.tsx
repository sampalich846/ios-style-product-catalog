import type { Metadata } from "next";
import "./globals.css";
import { Geist, PT_Sans } from "next/font/google";
import { cn } from "@/lib/utils";
import { BridgeProvider } from "@/components/bridge-provider";
import { Toaster } from "@/components/ui/sonner";
import { OnboardingGate } from "@/components/onboarding-flow";
import { SplashScreen } from "@/components/splash-screen";

const geist = Geist({ subsets: ["latin"], variable: "--font-sans" });
const ptSans = PT_Sans({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "700"],
  variable: "--font-pt-sans",
});

const appName = "У Палыча";

export const metadata: Metadata = {
  title: appName,
  description: appName,
  icons: {
    icon: "/icon.svg",
    apple: "/icon.svg",
  },
  appleWebApp: {
    capable: true,
    title: appName,
    statusBarStyle: "black-translucent",
  },
  manifest: "/manifest.webmanifest",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="ru"
      className={cn("font-sans", geist.variable, ptSans.variable)}
    >
      <body className="antialiased min-h-screen bg-background flex flex-col">
        <BridgeProvider />
        <SplashScreen />
        <main className="flex-1">
          <OnboardingGate>{children}</OnboardingGate>
        </main>
        <Toaster richColors position="top-right" />
      </body>
    </html>
  );
}
