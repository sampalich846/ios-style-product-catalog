"use client";

import { useCallback } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Store, Users, MapPin, Award } from "lucide-react";

export default function AboutPage() {
  const router = useRouter();

  const handleBack = useCallback(() => {
    router.back();
  }, [router]);

  return (
    <div className="min-h-dvh bg-white flex flex-col">
      <div className="sticky top-0 bg-white/90 backdrop-blur-lg z-10 border-b border-border/40">
        <div className="relative flex items-center h-14 px-4">
          <button
            onClick={handleBack}
            className="h-9 w-9 rounded-full bg-muted flex items-center justify-center transition-transform active:scale-90"
          >
            <ArrowLeft className="h-5 w-5 text-foreground" />
          </button>
          <h1 className="absolute left-1/2 -translate-x-1/2 text-base font-semibold">
            О компании
          </h1>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto ios-scroll">
        {/* Hero section */}
        <div className="bg-[#950a2b] px-5 pt-8 pb-10">
          <h2 className="text-2xl font-bold text-white tracking-tight">
            ТМ «У Палыча»
          </h2>
          <p className="text-white/80 text-sm mt-2 leading-relaxed">
            Более 30 лет радуем вас вкусными и качественными продуктами
          </p>
        </div>

        <div className="px-5 pt-6 pb-10 space-y-6">
          {/* История */}
          <section className="space-y-3">
            <p className="text-sm text-muted-foreground leading-relaxed">
              Более 30 лет назад началась история компании «У Палыча». В 1991
              году мы открыли первое кафе в Самаре. Дальше – больше.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Сегодня в России сложно найти человека, который хотя бы раз в
              жизни не пробовал нашу продукцию или не слышал о ней. Мы
              производим и продаем порядка 1450 наименований вкусных и
              по-настоящему качественных продуктов питания. Нас знают и охотно
              покупают жители Центрального, Приволжского, Северо-Западного и
              Южного федеральных округов. Два мощных производственных комплекса
              в Самаре и Москве выпускают фирменные продукты «У Палыча». И это
              только начало.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Мы не любим стоять на месте и постоянно работаем над расширением
              ассортимента и улучшением качества продукции, осваивая новые
              регионы. Идут годы – не меняется главное: продукты «У Палыча»
              всегда лучшие!
            </p>
          </section>

          {/* Ключевые факты в карточках */}
          <section className="grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-muted/30 p-4 space-y-2">
              <Award className="h-5 w-5 text-[#950a2b]" />
              <p className="text-xs font-semibold text-foreground">
                Более 30 лет успешной работы
              </p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                2021 год — 30-летний юбилей торговой марки «У Палыча».
              </p>
            </div>
            <div className="rounded-2xl bg-muted/30 p-4 space-y-2">
              <Store className="h-5 w-5 text-[#950a2b]" />
              <p className="text-xs font-semibold text-foreground">
                Более 15 000 торговых точек
              </p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Продукты представлены в крупнейших федеральных сетях.
              </p>
            </div>
            <div className="rounded-2xl bg-muted/30 p-4 space-y-2">
              <MapPin className="h-5 w-5 text-[#950a2b]" />
              <p className="text-xs font-semibold text-foreground">
                400 фирменных магазинов
              </p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Собственная розничная сеть в разных форматах.
              </p>
            </div>
            <div className="rounded-2xl bg-muted/30 p-4 space-y-2">
              <Users className="h-5 w-5 text-[#950a2b]" />
              <p className="text-xs font-semibold text-foreground">
                Более 1450 наименований
              </p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Торты, десерты, выпечка, полуфабрикаты и многое другое.
              </p>
            </div>
          </section>

          {/* Миссия */}
          <section className="rounded-2xl bg-gradient-to-br from-[#950a2b]/5 to-transparent p-5 space-y-3">
            <h3 className="text-sm font-semibold text-[#950a2b] tracking-widest uppercase">
              Миссия
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed italic">
              «Мы верим: каждая семья в России должна иметь возможность питаться
              здоровой и полезной пищей. Мы стремимся сделать так, чтобы
              качественные, полезные и вкусные продукты постоянно были на столе
              в каждом доме.»
            </p>
          </section>

          {/* Наши ценности */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-[#950a2b] tracking-widest uppercase">
              Наши ценности
            </h3>
            <div className="space-y-3">
              <div className="rounded-2xl bg-white shadow-sm ring-1 ring-foreground/5 p-4">
                <p className="text-sm font-semibold text-foreground mb-1">
                  Сохранение традиций, честность и постоянное развитие
                </p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Устойчивое развитие и открытость перед потребителями,
                  основанные на сохранении добрых традиций, – наши основные
                  ценности. Изо дня в день обеспечивать тысячи магазинов по всей
                  стране вашими любимыми продуктами нам помогают высокая
                  квалификация персонала, использование современных технологий
                  пищевой промышленности и жесткое соблюдение российских и
                  международных стандартов качества.
                </p>
              </div>
              <div className="rounded-2xl bg-white shadow-sm ring-1 ring-foreground/5 p-4">
                <p className="text-sm font-semibold text-foreground mb-1">
                  Наша цель — высокое качество вашего питания
                </p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Стремясь работать эффективнее, мы каждый день отбираем лучшее
                  сырье, используем высококачественные ингредиенты,
                  совершенствуем технологии и рецептуры, модернизируем
                  оборудование на производстве, следим за трендами мирового
                  пищевого рынка и с удовольствием воплощаем в жизнь самые
                  передовые и интересные кулинарные идеи.
                </p>
              </div>
              <div className="rounded-2xl bg-white shadow-sm ring-1 ring-foreground/5 p-4">
                <p className="text-sm font-semibold text-foreground mb-1">
                  Наш успех — это наши клиенты
                </p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Продукцию «У Палыча» выбирают миллионы россиян. Мы гордимся
                  этим. В основе многолетней лояльности — взаимное уважение:
                  наши продукты улучшают настроение и самочувствие клиентов, а
                  покупатели помогают компании расти и развиваться.
                </p>
              </div>
              <div className="rounded-2xl bg-white shadow-sm ring-1 ring-foreground/5 p-4">
                <p className="text-sm font-semibold text-foreground mb-1">
                  Наш капитал — сотрудники
                </p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Создавая для вас продукты «У Палыча», наши сотрудники
                  вкладывают в общее дело частички души. Работать с отдачей и от
                  чистого сердца могут только счастливые люди. Поэтому
                  добросовестный труд специалистов компании достойно
                  оплачивается, у членов команды есть возможности для личного
                  роста.
                </p>
              </div>
            </div>
          </section>

          {/* Ключевые направления деятельности */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-[#950a2b] tracking-widest uppercase">
              Ключевые направления деятельности
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Самара и Самарская область, Москва и Московская область – регионы,
              в которых производятся ваши любимые продукты «У Палыча».
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              На каждой из этих территорий мы с удовольствием ежедневно делаем
              кондитерские изделия (торты, пирожные, десерты), свежую и
              ароматную выпечку, а также замороженные полуфабрикаты и готовые
              блюда (супы, салаты и ланчи).
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              На новом пищевом комбинате в Самарской области выпускаем колбасы и
              мясные деликатесы. Здесь же расположен сырный цех, оснащенный
              современной климатической системой.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Комбинат в Москве и Московской области – один из ведущих в отрасли
              — выпускает более 500 видов кондитерских и хлебобулочных изделий,
              в том числе безглютеновую выпечку. Здесь же изготавливаются
              готовые блюда, в том числе свежие итальянские равиоли и паста!
            </p>
          </section>

          {/* Подвал */}
          <div className="border-t border-border/40 pt-4 mt-6">
            <p className="text-xs text-muted-foreground">
              Правообладателем ТМ «У Палыча» является ООО «Самарский Трактир».
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              ИНН 6315502936 | ОГРН 1026300960817
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
