"use client";

import { useState, useRef, useCallback, useMemo } from "react";
import { Search, RefreshCw, SlidersHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";
import { SiteHeader } from "@/components/site-header";
import { ProductCard } from "@/components/product-card";
import type { Product, ProductCategory } from "@/lib/schema";
import { CATEGORY_LABELS, CATEGORIES } from "@/lib/schema";

interface CatalogPageProps {
  products: Product[];
  favoriteIds: Set<string>;
  onToggleFavorite: (id: string) => void;
}

export function CatalogPage({
  products,
  favoriteIds,
  onToggleFavorite,
}: CatalogPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] =
    useState<ProductCategory | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const touchStartY = useRef(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const filteredProducts = useMemo(() => {
    let result = products;
    if (selectedCategory) {
      result = result.filter((p) => p.category === selectedCategory);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter((p) => p.name.toLowerCase().includes(q));
    }
    return result;
  }, [products, selectedCategory, searchQuery]);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (containerRef.current && containerRef.current.scrollTop <= 0) {
      touchStartY.current = e.touches[0].clientY;
    }
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (containerRef.current && containerRef.current.scrollTop <= 0) {
      const currentY = e.touches[0].clientY;
      const diff = currentY - touchStartY.current;
      if (diff > 0) {
        setPullDistance(Math.min(diff * 0.5, 120));
      }
    }
  }, []);

  const handleTouchEnd = useCallback(() => {
    if (pullDistance > 60 && !refreshing) {
      setRefreshing(true);
      setPullDistance(0);
      setTimeout(() => {
        setRefreshing(false);
      }, 1200);
    } else {
      setPullDistance(0);
    }
  }, [pullDistance, refreshing]);

  return (
    <div
      ref={containerRef}
      className="h-full overflow-y-auto overscroll-none bg-white ios-scroll"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Pull-to-refresh indicator */}
      <div
        className="flex justify-center transition-all duration-200 overflow-hidden"
        style={{
          height: pullDistance > 0 || refreshing ? pullDistance : 0,
          opacity: pullDistance > 0 || refreshing ? 1 : 0,
        }}
      >
        <div className="flex items-center gap-2 text-sm text-muted-foreground mt-3">
          <RefreshCw
            className={cn(
              "h-4 w-4",
              refreshing && "animate-spin",
              !refreshing &&
                pullDistance > 60 &&
                "rotate-180 transition-transform duration-200"
            )}
          />
          <span>
            {refreshing
              ? "Обновляем..."
              : pullDistance > 60
                ? "Отпустите для обновления"
                : "Потяните для обновления"}
          </span>
        </div>
      </div>

      {/* Site Header */}
      <SiteHeader />

      {/* Search bar */}
      <div className="px-5 pt-3 pb-3">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Поиск"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-10 pl-10 pr-4 rounded-xl bg-muted text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 transition-shadow"
          />
        </div>
      </div>

      {/* Category chips */}
      <div className="pb-3">
        <div className="flex gap-2 overflow-x-auto px-5 scrollbar-hide">
          {CATEGORIES.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(isActive ? null : cat)}
                className={cn(
                  "shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200",
                  isActive
                    ? "bg-foreground text-background shadow-sm"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                )}
              >
                {CATEGORY_LABELS[cat]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Product grid */}
      <div className="px-5 pb-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {filteredProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center pt-16 pb-8 text-muted-foreground col-span-full">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted mb-3">
              <SlidersHorizontal className="h-5 w-5" />
            </div>
            <p className="text-sm">Ничего не найдено</p>
          </div>
        ) : (
          filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              isFavorite={favoriteIds.has(product.id)}
              onToggleFavorite={onToggleFavorite}
            />
          ))
        )}
      </div>
    </div>
  );
}
