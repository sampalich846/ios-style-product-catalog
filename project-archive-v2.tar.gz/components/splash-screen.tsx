"use client";

import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

export function SplashScreen() {
  const [visible, setVisible] = useState(true);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFadeOut(true);
      setTimeout(() => setVisible(false), 500);
    }, 1200);

    return () => clearTimeout(timer);
  }, []);

  if (!visible) return null;

  return (
    <div
      className={cn(
        "fixed inset-0 z-[9999] flex flex-col items-center justify-center",
        "transition-opacity duration-500 ease-in-out",
        fadeOut ? "opacity-0" : "opacity-100"
      )}
      style={{ backgroundColor: "#A70230" }}
    >
      <div className="animate-in fade-in zoom-in-95 duration-700 flex flex-col items-center gap-5">
        <div className="rounded-3xl bg-white/10 p-4 shadow-xl backdrop-blur-sm">
          <img src="/main-logo.svg" alt="Логотип" className="h-16 w-auto" />
        </div>
        <div className="flex gap-1.5 mt-4">
          <span
            className="h-2 w-2 rounded-full bg-white/40 animate-bounce"
            style={{ animationDelay: "0ms" }}
          />
          <span
            className="h-2 w-2 rounded-full bg-white/60 animate-bounce"
            style={{ animationDelay: "150ms" }}
          />
          <span
            className="h-2 w-2 rounded-full bg-white/80 animate-bounce"
            style={{ animationDelay: "300ms" }}
          />
        </div>
      </div>
    </div>
  );
}
