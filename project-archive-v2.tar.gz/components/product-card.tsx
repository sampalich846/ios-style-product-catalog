"use client";

import { useRouter } from "next/navigation";
import { Heart } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Product } from "@/lib/schema";

interface ProductCardProps {
  product: Product;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
}

export function ProductCard({
  product,
  isFavorite,
  onToggleFavorite,
}: ProductCardProps) {
  const router = useRouter();

  return (
    <button
      onClick={() => router.push(`/products/${product.id}`)}
      className="relative w-full text-left overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-foreground/5 transition-all duration-200 card-hover"
    >
      <div className="aspect-square bg-muted overflow-hidden">
        <img
          src={product.photo}
          alt={product.name}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(product.id);
          }}
          className="absolute top-2 right-2 flex h-7 w-7 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm shadow-sm transition-all duration-200 active:scale-90 hover:bg-white"
          aria-label={
            isFavorite ? "Убрать из избранного" : "Добавить в избранное"
          }
        >
          <Heart
            className={cn(
              "h-4 w-4 transition-all duration-200",
              isFavorite
                ? "fill-red-500 text-red-500"
                : "fill-none text-foreground/70"
            )}
            strokeWidth={isFavorite ? 2.5 : 2}
          />
        </button>
      </div>
      <div className="p-3 space-y-1">
        <h3 className="text-sm font-semibold leading-snug text-foreground line-clamp-2">
          {product.name}
        </h3>
      </div>
    </button>
  );
}
