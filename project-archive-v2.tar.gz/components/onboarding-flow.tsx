"use client";

import { useState, useCallback, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Store, Heart, Phone, ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const ONBOARDING_KEY = "u-palycha_onboarding_completed";

export function isOnboardingCompleted(): boolean {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(ONBOARDING_KEY) === "true";
}

export function completeOnboarding(): void {
  localStorage.setItem(ONBOARDING_KEY, "true");
}

const slides = [
  {
    icon: Store,
    description:
      "Откройте для себя мир домашней выпечки и десертов. Торты, пирожные, пироги, мороженое и заморозка — всё с любовью и из натуральных продуктов.",
  },
  {
    icon: Heart,
    title: "Сохраняйте любимое",
    description:
      "Добавляйте товары в избранное, чтобы быстро находить их позже. Просто нажмите на сердечко на карточке товара.",
  },
  {
    icon: Phone,
    title: "Всегда на связи",
    description:
      "Звоните нам по единому номеру 8 (800) 555-81-63. На карте магазинов вы найдёте адреса и часы работы.",
  },
];

export function OnboardingGate({ children }: { children: React.ReactNode }) {
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setHydrated(true);
  }, []);

  if (!hydrated) return null;

  const completed = localStorage.getItem(ONBOARDING_KEY) === "true";

  if (!completed) {
    return <OnboardingFlow />;
  }

  return <>{children}</>;
}

export function OnboardingFlow() {
  const [step, setStep] = useState(0);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const router = useRouter();

  const handleNext = useCallback(() => {
    if (step < slides.length - 1) {
      setStep((s) => s + 1);
    } else {
      setShowPrivacy(true);
    }
  }, [step]);

  const handleStart = useCallback(() => {
    if (!privacyAccepted) return;
    completeOnboarding();
    router.refresh();
  }, [privacyAccepted, router]);

  if (showPrivacy) {
    return (
      <div className="h-dvh bg-white flex flex-col animate-in fade-in duration-500">
        <div className="flex-1 overflow-y-auto ios-scroll px-5 pt-16 pb-6">
          <div className="flex justify-center mb-6">
            <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Check className="h-8 w-8 text-primary" />
            </div>
          </div>

          <h1 className="text-2xl font-bold text-center mb-2">
            Политика конфиденциальности
          </h1>
          <p className="text-sm text-muted-foreground text-center mb-6">
            Ознакомьтесь с условиями обработки персональных данных
          </p>

          <div className="bg-muted/50 rounded-2xl p-5 space-y-4 text-sm text-muted-foreground leading-relaxed">
            <p>
              Настоящая Политика конфиденциальности (далее — Политика) действует
              в отношении всей информации, которую приложение «У Палыча» может
              получить о пользователе во время использования мобильного
              приложения.
            </p>

            <h3 className="font-semibold text-foreground">
              1. Сбор информации
            </h3>
            <p>
              Приложение не собирает и не передаёт персональные данные
              пользователей третьим лицам. Вся информация (избранные товары)
              хранится локально на устройстве пользователя.
            </p>

            <h3 className="font-semibold text-foreground">
              2. Использование информации
            </h3>
            <p>
              Информация, хранящаяся на устройстве, используется исключительно
              для функционирования приложения: отображения каталога товаров,
              сохранения избранного и обеспечения работы контактной информации.
            </p>

            <h3 className="font-semibold text-foreground">
              3. Передача данных третьим лицам
            </h3>
            <p>
              Приложение не передаёт персональные данные пользователей третьим
              лицам. Приложение не использует сторонние аналитические сервисы,
              собирающие данные о пользователях.
            </p>

            <h3 className="font-semibold text-foreground">
              4. Ссылки на внешние сайты
            </h3>
            <p>
              Приложение может содержать ссылки на внешние ресурсы (телефонные
              номера). При переходе по внешним ссылкам пользователь покидает
              приложение, и Политика конфиденциальности на эти ресурсы не
              распространяется.
            </p>

            <h3 className="font-semibold text-foreground">
              5. Изменение Политики
            </h3>
            <p>
              Администрация приложения оставляет за собой право вносить
              изменения в настоящую Политику конфиденциальности. Новая версия
              Политики вступает в силу с момента её опубликования в приложении.
            </p>

            <p className="text-xs text-muted-foreground/60 pt-2">
              Последнее обновление: июль 2026 г.
            </p>
          </div>
        </div>

        <div className="px-5 pb-10 pt-2 space-y-3 border-t border-border/40">
          <label className="flex items-start gap-3 py-2 cursor-pointer">
            <input
              type="checkbox"
              checked={privacyAccepted}
              onChange={(e) => setPrivacyAccepted(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-muted-foreground text-primary focus:ring-primary"
            />
            <span className="text-sm text-muted-foreground leading-snug">
              Я принимаю условия{" "}
              <button
                onClick={(e) => {
                  e.preventDefault();
                  window.open("/privacy", "_blank");
                }}
                className="text-primary underline underline-offset-2"
              >
                Политики конфиденциальности
              </button>
            </span>
          </label>

          <Button
            onClick={handleStart}
            disabled={!privacyAccepted}
            className="w-full h-12 rounded-xl text-base font-semibold"
          >
            Начать пользоваться
          </Button>
        </div>
      </div>
    );
  }

  const slide = slides[step];
  const Icon = slide.icon;

  return (
    <div className="h-dvh bg-white flex flex-col animate-in fade-in duration-500">
      <div className="flex-1 flex flex-col items-center justify-center px-8">
        <div className="h-24 w-24 rounded-3xl bg-primary/10 flex items-center justify-center mb-8">
          <Icon className="h-12 w-12 text-primary" />
        </div>

        <div className="flex gap-1.5 mb-6">
          {slides.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                i === step ? "w-8 bg-primary" : "w-1.5 bg-muted-foreground/20"
              }`}
            />
          ))}
        </div>

        {slide.title && (
          <h1 className="text-2xl font-bold text-center mb-3 tracking-tight">
            {slide.title}
          </h1>
        )}
        <p className="text-sm text-muted-foreground text-center leading-relaxed max-w-sm">
          {slide.description}
        </p>
      </div>

      <div className="px-5 pb-12">
        <Button
          onClick={handleNext}
          className="w-full h-12 rounded-xl text-base font-semibold gap-2"
        >
          {step < slides.length - 1 ? "Далее" : "О политике"}
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
