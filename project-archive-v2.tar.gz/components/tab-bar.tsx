"use client";

import { House, Heart, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";

type TabId = "catalog" | "favorites" | "contacts";

interface TabBarProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
}

const tabs: { id: TabId; label: string; icon: typeof House }[] = [
  { id: "catalog", label: "Главная", icon: House },
  { id: "favorites", label: "Избранное", icon: Heart },
  { id: "contacts", label: "Где купить", icon: MapPin },
];

export function TabBar({ activeTab, onTabChange }: TabBarProps) {
  return (
    <nav className="flex items-center justify-around h-14 px-2 bg-white/90 backdrop-blur-lg border-t border-border/40 safe-area-bottom">
      {tabs.map(({ id, label, icon: Icon }) => {
        const isActive = activeTab === id;
        return (
          <button
            key={id}
            onClick={() => onTabChange(id)}
            className={cn(
              "flex flex-col items-center justify-center gap-0.5 h-full px-4 transition-all duration-200 relative",
              isActive ? "opacity-100" : "opacity-40 hover:opacity-60"
            )}
          >
            <Icon
              className={cn(
                "h-5 w-5 transition-all duration-200",
                isActive ? "fill-current" : "fill-none"
              )}
              strokeWidth={isActive ? 2.5 : 2}
            />
            <span
              className={cn(
                "text-[10px] font-medium leading-none transition-all duration-200",
                isActive && "font-semibold"
              )}
            >
              {label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}

export type { TabId };
