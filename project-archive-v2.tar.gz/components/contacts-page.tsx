"use client";

import { useCallback, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, MapPin, Phone, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Store } from "@/lib/schema";

interface ContactsPageProps {
  stores: Store[];
  onBack?: () => void;
}

function triggerHaptic() {
  if (typeof navigator !== "undefined" && navigator.vibrate) {
    navigator.vibrate(10);
  }
}

export function ContactsPage({ stores, onBack }: ContactsPageProps) {
  const router = useRouter();

  const handleBack = useCallback(() => {
    if (onBack) {
      onBack();
    } else {
      router.back();
    }
  }, [onBack, router]);
  const [selectedStoreId, setSelectedStoreId] = useState<string | null>(null);

  const handleCall = useCallback((phone: string) => {
    triggerHaptic();
    const cleaned = phone.replace(/[^+\d]/g, "");
    window.location.href = `tel:${cleaned}`;
  }, []);

  const handleSelectStore = useCallback((id: string) => {
    setSelectedStoreId((prev) => (prev === id ? null : id));
    triggerHaptic();
  }, []);

  return (
    <div className="h-full flex flex-col overflow-y-auto ios-scroll bg-muted/30 relative">
      {/* Back button */}
      <button
        onClick={handleBack}
        className="absolute top-12 left-4 h-9 w-9 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center shadow-sm transition-transform active:scale-90 z-10"
      >
        <ArrowLeft className="h-5 w-5 text-foreground" />
      </button>
      <div className="px-5 pt-24 pb-3">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">
          Где купить
        </h1>
      </div>

      <div className="px-5 pb-8 space-y-3">
        {stores.map((store) => {
          const isSelected = store.id === selectedStoreId;
          return (
            <div
              key={store.id}
              data-store-id={store.id}
              onClick={() => handleSelectStore(store.id)}
              className={`rounded-2xl bg-white shadow-sm ring-1 overflow-hidden transition-all duration-200 cursor-pointer ${
                isSelected
                  ? "ring-primary ring-2 shadow-md"
                  : "ring-foreground/5"
              }`}
            >
              <div className="p-5">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                    <p className="text-sm text-muted-foreground leading-snug">
                      {store.address}
                    </p>
                  </div>

                  <div className="flex items-start gap-3">
                    <Phone className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                    <a
                      href={`tel:${store.phone.replace(/[^+\d]/g, "")}`}
                      className="text-sm text-primary hover:underline leading-snug"
                    >
                      {store.phone}
                    </a>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                    <p className="text-sm text-muted-foreground leading-snug">
                      {store.hours}
                    </p>
                  </div>
                </div>
              </div>

              <div className="px-5 pb-4">
                <Button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleCall(store.phone);
                  }}
                  className="w-full h-11 rounded-xl text-sm font-semibold gap-2"
                >
                  <Phone className="h-4 w-4" />
                  Позвонить
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
