"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Heart, Store } from "lucide-react";
import { cn } from "@/lib/utils";
import { getFavoriteIds, toggleFavoriteId } from "@/lib/favorites";
import type { Product } from "@/lib/schema";

interface ProductDetailProps {
  product: Product;
}

export function ProductDetail({ product }: ProductDetailProps) {
  const router = useRouter();
  const [favoriteIds, setFavoriteIds] = useState<string[]>(getFavoriteIds);
  const isFavorite = favoriteIds.includes(product.id);

  function handleToggleFavorite() {
    toggleFavoriteId(product.id);
    setFavoriteIds(getFavoriteIds());
  }

  return (
    <div className="h-dvh bg-white flex flex-col">
      <div className="relative flex-1 overflow-y-auto ios-scroll">
        {/* Hero image */}
        <div className="relative h-[50vh] min-h-[320px] bg-muted overflow-hidden animate-in fade-in duration-700">
          <img
            src={product.photo}
            alt={product.name}
            className="w-full h-full object-cover"
          />

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/40" />

          {/* Back button */}
          <button
            onClick={() => router.back()}
            className="absolute top-12 left-4 h-9 w-9 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center shadow-sm transition-transform active:scale-90"
          >
            <ArrowLeft className="h-5 w-5 text-foreground" />
          </button>

          {/* Favorite button */}
          <button
            onClick={handleToggleFavorite}
            className="absolute top-12 right-4 flex h-9 w-9 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm shadow-sm transition-all duration-200 active:scale-90 hover:bg-white"
            aria-label={
              isFavorite ? "Убрать из избранного" : "Добавить в избранное"
            }
          >
            <Heart
              className={cn(
                "h-5 w-5 transition-all duration-200",
                isFavorite
                  ? "fill-red-500 text-red-500"
                  : "fill-none text-foreground/70"
              )}
              strokeWidth={isFavorite ? 2.5 : 2}
            />
          </button>
        </div>

        {/* Content */}
        <div className="px-5 pt-5 pb-8 space-y-5">
          {/* Title */}
          <h1 className="text-3xl font-bold tracking-tight text-foreground animate-in fade-in duration-500 delay-75">
            {product.name}
          </h1>

          {/* Weight */}
          <div className="animate-in fade-in duration-500 delay-75">
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-muted text-xs font-medium text-muted-foreground">
              <span className="tracking-wide">{product.weight}</span>
            </div>
          </div>

          {/* Description */}
          <div className="animate-in fade-in duration-500 delay-75">
            <h2 className="text-sm font-semibold text-foreground/60 uppercase tracking-wider mb-2">
              Описание
            </h2>
            <p className="text-base leading-relaxed text-foreground/80">
              {product.description}
            </p>
          </div>

          {/* Ingredients */}
          <div className="animate-in fade-in duration-500 delay-75">
            <h2 className="text-sm font-semibold text-foreground/60 uppercase tracking-wider mb-2">
              Состав
            </h2>
            <p className="text-base leading-relaxed text-foreground/80">
              {product.ingredients}
            </p>
          </div>
        </div>
      </div>

      {/* Где купить button */}
      <div className="bg-white px-5 pb-8 pt-4 animate-in fade-in duration-500 delay-75">
        <button
          onClick={() => router.push("/contacts")}
          className="w-full h-14 rounded-2xl bg-primary text-primary-foreground text-base font-semibold tracking-wide shadow-lg shadow-primary/30 flex items-center justify-center gap-2 active:scale-[0.97] transition-all duration-150"
        >
          <Store className="h-5 w-5" />
          Где купить
        </button>
      </div>
    </div>
  );
}
