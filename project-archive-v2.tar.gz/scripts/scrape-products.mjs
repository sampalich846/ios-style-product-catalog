import { chromium } from "playwright";

const CAKE_URLS = [
  "https://msk.palich.ru/catalog/torty/91708/zalcburgskiy_shokolad_s_yagodami_tort_500_g/",
  "https://msk.palich.ru/catalog/torty/2313/orehovyy_po_korolevski_tort_850_g/",
  "https://msk.palich.ru/catalog/torty/35968/praga_originalnaya_tort_500_g/",
  "https://msk.palich.ru/catalog/torty/23789/molochnaya_devochka_tort_750_g/",
  "https://msk.palich.ru/catalog/torty/2281/malinovyy_tort_900_g/",
  "https://msk.palich.ru/catalog/torty/2344/kievskiy_originalnyy_tort_500_g/",
  "https://msk.palich.ru/catalog/torty/39203/krasnyy_barhat_tort_850_g/",
  "https://msk.palich.ru/catalog/torty/2290/skazki_vostoka_assorti_tort_1200_g/",
  "https://msk.palich.ru/catalog/torty/92382/malina_v_tropikah_tort_500_g/",
  "https://msk.palich.ru/catalog/torty/36006/napoleon_tort_900_g/",
  "https://msk.palich.ru/catalog/torty/80720/pesochnyy_tort_s_malinoy_i_solenoy_karamelyu_800_g/",
  "https://msk.palich.ru/catalog/torty/82763/merengovyy_rulet_s_fistashkoy_i_malinoy_400_g/",
  "https://msk.palich.ru/catalog/torty/36024/praga_originalnaya_tort_900_g/",
  "https://msk.palich.ru/catalog/torty/30525/sladkiy_zoopark_edinorog_tort_1200_g/",
  "https://msk.palich.ru/catalog/torty/36013/s_chernoslivom_originalnyy_tort_1200_g/",
  "https://msk.palich.ru/catalog/torty/36032/lesnaya_yagoda_s_vishney_tort_1450_g/",
  "https://msk.palich.ru/catalog/torty/35991/leningradskiy_originalnyy_tort_650_g/",
  "https://msk.palich.ru/catalog/torty/2245/blinnyy_s_fistashkoy_tort_900_g/",
  "https://msk.palich.ru/catalog/torty/2224/s_chernoslivom_originalnyy_tort_1450_g/",
  "https://msk.palich.ru/catalog/torty/111860/yagodnaya_mechta_tort_550_g/",
];

const PASTRY_URLS = [
  "https://msk.palich.ru/catalog/pirozhnye_i_deserty/",
  "https://msk.palich.ru/catalog/pirozhnye_i_deserty/?PAGEN_1=2",
];

function cleanName(title) {
  return title
    .replace(/ от Палыча с доставкой на дом$/, "")
    .replace(/ от Палыча с доставкой$/, "")
    .replace(/ с доставкой на дом$/, "")
    .replace(/к Дню семьи, любви и верности /g, "")
    .replace(/к Дню семьи, любви и верности$/g, "")
    .trim();
}

async function scrape(browser, url) {
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: "networkidle", timeout: 30000 });

  const title = cleanName(await page.title());

  const images = await page.evaluate(() => {
    const imgs = document.querySelectorAll(".swiper-slide__img");
    return imgs.length > 0 ? imgs[0].src : "";
  });

  const description = await page.evaluate(() => {
    const h2s = document.querySelectorAll("h2");
    for (const h2 of h2s) {
      if (h2.textContent.includes("Описание")) {
        let el = h2.nextElementSibling;
        while (el) {
          const text = el.textContent.trim();
          if (text && text !== "Описание товара") {
            return text.replace(/\s+/g, " ").trim();
          }
          el = el.nextElementSibling;
        }
      }
    }
    return "";
  });

  const ingredientsFull = await page.evaluate(() => {
    const h3s = document.querySelectorAll("h3");
    for (const h3 of h3s) {
      if (h3.textContent.includes("Состав")) {
        let el = h3.nextElementSibling;
        let texts = [];
        while (el && el.tagName !== "H3" && el.tagName !== "H2") {
          const txt = el.textContent.trim();
          if (txt) texts.push(txt);
          el = el.nextElementSibling;
        }
        return texts.join(" ").replace(/\s+/g, " ").trim();
      }
    }
    return "";
  });

  let ingredients = ingredientsFull;
  const nutritionMatch = ingredientsFull.match(/белки[\s\S]{0,200}кДж\./i);
  if (nutritionMatch) {
    ingredients = ingredientsFull
      .substring(nutritionMatch.index + nutritionMatch[0].length)
      .trim();
  }
  ingredients = ingredients
    .replace(/\n/g, " ")
    .replace(/\s+/g, " ")
    .replace(/^[^А-ЯA-Z]+/, "")
    .replace(/Произведено[\s\S]*$/, "")
    .replace(/Развернуть.*$/, "")
    .trim();
  ingredients = ingredients.replace(/,\s*$/, "").trim();

  const weightMatch = title.match(/(\d+)\s*г/);
  const weight = weightMatch ? weightMatch[0] : "";

  console.log(
    JSON.stringify(
      { title, weight, description, ingredients, image: images },
      null,
      2
    )
  );
  await page.close();
  return { title, weight, description, ingredients, image: images };
}

async function getPastryLinks(browser, url) {
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: "networkidle", timeout: 30000 });
  const links = await page.evaluate(() => {
    const items = document.querySelectorAll(
      '[class*="product-card"] a, a[href*="/catalog/pirozhnye_i_deserty/"]'
    );
    const seen = new Set();
    const result = [];
    items.forEach((a) => {
      const h = a.href;
      if (
        h &&
        h.includes("/catalog/pirozhnye_i_deserty/") &&
        h.match(/\d+\//) &&
        !seen.has(h)
      ) {
        seen.add(h);
        result.push(h);
      }
    });
    return result;
  });
  await page.close();

  const seen = new Set();
  return links.filter((h) => {
    if (seen.has(h)) return false;
    seen.add(h);
    return true;
  });
}

async function main() {
  const browser = await chromium.launch({ headless: true });

  // Scrape cakes
  const cakeResults = [];
  for (const url of CAKE_URLS.slice(0, 12)) {
    try {
      const data = await scrape(browser, url);
      cakeResults.push(data);
      console.error(`[OK] ${data.title}`);
    } catch (e) {
      console.error(`[ERR] ${url}: ${e.message}`);
    }
  }

  // Get pastry links from catalog pages
  console.error("\n--- Getting pastry links ---");
  const pastryLinks = [];
  for (const url of PASTRY_URLS) {
    const links = await getPastryLinks(browser, url);
    pastryLinks.push(...links);
    console.error(`Found ${links.length} links from ${url}`);
  }

  // Deduplicate and filter
  const seen = new Set();
  const uniquePastryLinks = pastryLinks.filter((h) => {
    if (seen.has(h)) return false;
    seen.add(h);
    return true;
  });

  // Scrape pastries (skip ones already in mock data)
  const existingPastryNames = [
    "Прага пирожные-канапе 700 г",
    "Корзиночка пирожные 280 г",
    "Малиновое пирожные-канапе 900 г",
    "Наполеон оригинальное пирожные-канапе 650 г",
    "Корзиночка Оригинальная пирожные 280 г",
    "Чизкейк с ягодами пирожные 310 г",
    "Донат с карамельным шоколадом 30 г",
    "Снежная малина пирожные 185 г",
    "Киевское оригинальное пирожные-канапе 450 г",
  ];

  const pastryResults = [];
  for (const url of uniquePastryLinks.slice(0, 15)) {
    try {
      const data = await scrape(browser, url);
      const isExisting = existingPastryNames.some((n) =>
        data.title.toLowerCase().includes(
          n
            .toLowerCase()
            .replace(/[^а-яa-z0-9\s]/g, "")
            .trim()
        )
      );
      if (!isExisting) {
        pastryResults.push(data);
        console.error(`[OK] ${data.title}`);
      } else {
        console.error(`[SKIP] Already exists: ${data.title}`);
      }
    } catch (e) {
      console.error(`[ERR] ${url}: ${e.message}`);
    }
  }

  console.log("\n\n=== CAKES ===");
  console.log(JSON.stringify(cakeResults, null, 2));
  console.log("\n=== PASTRIES ===");
  console.log(JSON.stringify(pastryResults, null, 2));

  await browser.close();
}

main().catch(console.error);
