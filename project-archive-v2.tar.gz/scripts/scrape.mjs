import { chromium } from "playwright";
import { writeFileSync } from "fs";

const CATEGORIES = [
  { id: "cakes", slug: "torty", mockCategory: "cakes" },
  { id: "pastries", slug: "pirozhnye_i_deserty", mockCategory: "pastries" },
  { id: "pies", slug: "3pie-01", mockCategory: "pies" },
  { id: "ice-cream", slug: "morozhenoe_i_sorbety", mockCategory: "ice-cream" },
  {
    id: "frozen-pelmeni",
    slug: "pelmeni_manty_hinkali_ravioli_zamorozhennye",
    mockCategory: "frozen",
  },
  {
    id: "frozen-ready",
    slug: "blinchiki_syrniki_zamorozhennye",
    mockCategory: "frozen",
  },
];

async function extractProducts(page, categorySlug) {
  const url = `https://msk.palich.ru/catalog/${categorySlug}/`;
  await page.goto(url, { waitUntil: "networkidle", timeout: 30000 });
  await page.waitForTimeout(1000);

  return await page.evaluate(() => {
    const items = document.querySelectorAll(".products__item");
    return Array.from(items).map((item) => {
      const nameEl = item.querySelector(".products__item__name");
      const imgEl = item.querySelector(".products__item__slide__img");
      const linkEl = item.querySelector(".products__item__slide__link");

      const name = nameEl ? nameEl.textContent.trim() : "";
      const imgSrc = imgEl ? imgEl.getAttribute("src") : "";
      const url = linkEl ? linkEl.getAttribute("href") : "";
      const weightMatch = name.match(/(\d+[\s]*(?:г|кг|мл|л))/i);
      const weight = weightMatch ? weightMatch[1].trim() : "";

      return { name, imgSrc, url, weight };
    });
  });
}

function getLargerImgUrl(imgSrc) {
  if (!imgSrc) return "";
  if (imgSrc.startsWith("http")) {
    // Try to get larger version by replacing size
    return imgSrc.replace(/\/\d+x\d+\//, "/585x585/");
  }
  const full = `https://msk.palich.ru${imgSrc}`;
  return full.replace(/\/\d+x\d+\//, "/585x585/");
}

async function extractDetail(page, url) {
  try {
    await page.goto(url, { waitUntil: "networkidle", timeout: 20000 });
    await page.waitForTimeout(500);

    return await page.evaluate(() => {
      const descEl = document.querySelector("#product-descr-second");
      let description = descEl ? descEl.innerText.trim() : "";
      // Remove "Описание товара" prefix
      description = description.replace(/^Описание товара\s*\n/, "").trim();

      const ingredEl = document.querySelector("#product-descr");
      let ingredients = ingredEl ? ingredEl.innerText.trim() : "";
      // Remove "Состав и пищевая ценность" prefix and everything after "Развернуть"
      ingredients = ingredients.replace(/^Состав и пищевая ценность\s*\n/, "");
      // Keep only the ingredients part (before "Развернуть" or "Дополнительные характеристики")
      const splitMarkers = [
        "\nРазвернуть\n",
        "\nДополнительные характеристики\n",
      ];
      for (const marker of splitMarkers) {
        const idx = ingredients.indexOf(marker);
        if (idx !== -1) ingredients = ingredients.substring(0, idx);
      }
      ingredients = ingredients
        .replace(/\n\n\n/g, "\n")
        .replace(/\n\n/g, "\n")
        .trim();
      // If ingredients is just nutritional info (starts with "Пищевая ценность"), take the part after it
      // Actually the raw ingredients list is after the nutritional info
      const lines = ingredients.split("\n").filter((l) => l.trim());
      // Find the ingredients list (longest line or line without numbers/ккал)
      let ingrText = "";
      for (const line of lines) {
        if (
          line.length > 30 &&
          !line.match(
            /ккал|Энергетическая|Пищевая|белки|жиры|углеводы|Развернуть/i
          )
        ) {
          ingrText = line.trim();
          break;
        }
      }
      if (!ingrText && lines.length > 0) {
        // Fallback: take everything except header
        ingrText = ingredients;
      }

      // Get the large product image from gallery
      const imgEl = document.querySelector(".swiper-slide__img");
      let imgUrl = "";
      if (imgEl) {
        const src = imgEl.getAttribute("src");
        if (src) {
          imgUrl = src.startsWith("http") ? src : `https://msk.palich.ru${src}`;
        }
      }

      return { description, ingredients: ingrText || ingredients, imgUrl };
    });
  } catch (e) {
    return { description: "", ingredients: "", imgUrl: "" };
  }
}

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    userAgent:
      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
  });
  const page = await context.newPage();

  const allResults = {};

  for (const cat of CATEGORIES) {
    console.error(`\n=== Category: ${cat.id} (${cat.slug}) ===`);
    const products = await extractProducts(page, cat.slug);
    console.error(`Total products found: ${products.length}`);

    const topProducts = products.slice(0, 10);

    for (let i = 0; i < topProducts.length; i++) {
      const p = topProducts[i];
      const detailUrl = p.url ? `https://msk.palich.ru${p.url}` : "";

      let description = "";
      let ingredients = "";
      let detailImgUrl = "";

      if (detailUrl) {
        const detail = await extractDetail(page, detailUrl);
        description = detail.description;
        ingredients = detail.ingredients;
        detailImgUrl = detail.imgUrl;
      }

      const imgUrl = detailImgUrl || getLargerImgUrl(p.imgSrc);

      console.error(`${i + 1}. ${p.name}`);
      console.error(`   Вес: ${p.weight}`);
      console.error(`   Описание: ${description.substring(0, 80)}...`);

      if (!allResults[cat.mockCategory]) {
        allResults[cat.mockCategory] = [];
      }
      allResults[cat.mockCategory].push({
        name: p.name,
        imgUrl,
        weight: p.weight,
        description,
        ingredients,
        sourceCategory: cat.id,
      });
    }
  }

  await browser.close();

  // Print JSON to stdout ONLY
  const json = JSON.stringify(allResults, null, 2);
  console.log(json);
})();
