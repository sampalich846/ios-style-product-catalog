import { chromium } from "playwright";
import { writeFileSync } from "fs";

const PRODUCTS = [
  {
    name: "Колбаса вареная Докторская 450г",
    url: "/catalog/kolbasa_i_delikatesy/4695/kolbasa_varenaya_doktorskaya_450g/",
    weight: "450г",
  },
  {
    name: "Колбаса Краковская полукопченая 300г",
    url: "/catalog/kolbasa_i_delikatesy/4700/kolbasa__krakovskaya_polukopchenaya_300g/",
    weight: "300г",
  },
  {
    name: "Колбаса варено-копченая Московская 310г",
    url: "/catalog/kolbasa_i_delikatesy/4710/kolbasa_vareno_kopchenaya_moskovskaya_310g/",
    weight: "310г",
  },
  {
    name: "Колбаса Брауншвейгская 250 г",
    url: "/catalog/kolbasa_i_delikatesy/74283/kolbasa_braunshveygskaya_250_g/",
    weight: "250 г",
  },
  {
    name: "Колбаса Еврейская 250 г",
    url: "/catalog/kolbasa_i_delikatesy/74285/kolbasa_evreyskaya_250_g/",
    weight: "250 г",
  },
  {
    name: "Колбаса Домашняя говяжья 170 г",
    url: "/catalog/kolbasa_i_delikatesy/88553/kolbasa_domashnyaya_govyazhya_170_g/",
    weight: "170 г",
  },
  {
    name: "Сосиски Молочные 300г",
    url: "/catalog/kolbasa_i_delikatesy/4553/sosiski_molochnye_300g/",
    weight: "300г",
  },
  {
    name: "Колбаса КиндерВюрст 450 г",
    url: "/catalog/kolbasa_i_delikatesy/56097/kolbasa_kindervyurst_450_g/",
    weight: "450 г",
  },
  {
    name: "Колбаски Пепперони Россо 96 г",
    url: "/catalog/kolbasa_i_delikatesy/113689/kolbaski_pepperoni_rosso_96_g/",
    weight: "96 г",
  },
  {
    name: "Курица по-боярски с паприкой 395-476 г",
    url: "/catalog/kolbasa_i_delikatesy/4533/kurica_po_boyarski_s_paprikoy_395_476_g/",
    weight: "476 г",
  },
  {
    name: "Колбаса вареная Телячья 450г",
    url: "/catalog/kolbasa_i_delikatesy/4699/kolbasa_varenaya_telyachya_450g/",
    weight: "450г",
  },
  {
    name: "Сервелат варено-копченый 310г",
    url: "/catalog/kolbasa_i_delikatesy/4713/servelat_vareno_kopchenyy_310g/",
    weight: "310г",
  },
  {
    name: "Ветчина из филе индейки 450 г",
    url: "/catalog/kolbasa_i_delikatesy/5113/vetchina_iz_file_indeyki_450_g/",
    weight: "450 г",
  },
  {
    name: "Колбаса из индейки 310 г",
    url: "/catalog/kolbasa_i_delikatesy/26310/kolbasa_iz_indeyki_310_g/",
    weight: "310 г",
  },
  {
    name: "Сервелат из говядины 310 г",
    url: "/catalog/kolbasa_i_delikatesy/66046/servelat_iz_govyadiny_310_g/",
    weight: "310 г",
  },
  {
    name: "Колбаса с брусникой 250 г",
    url: "/catalog/kolbasa_i_delikatesy/74281/kolbasa_s_brusnikoy_250_g/",
    weight: "250 г",
  },
  {
    name: "Колбаса Виченза Пиканто 250 г",
    url: "/catalog/kolbasa_i_delikatesy/74282/kolbasa_vichenza_pikanto_250_g/",
    weight: "250 г",
  },
  {
    name: "Салями Мачерата 250 г",
    url: "/catalog/kolbasa_i_delikatesy/74287/salyami_macherata_250_g/",
    weight: "250 г",
  },
];

async function extractDetail(page, url) {
  try {
    await page.goto(url, { waitUntil: "networkidle", timeout: 20000 });
    await page.waitForTimeout(500);
    return await page.evaluate(() => {
      const descEl = document.querySelector("#product-descr-second");
      let description = descEl ? descEl.innerText.trim() : "";
      description = description.replace(/^Описание товара\s*\n/, "").trim();
      const ingredEl = document.querySelector("#product-descr");
      let ingredients = ingredEl ? ingredEl.innerText.trim() : "";
      ingredients = ingredients.replace(/^Состав и пищевая ценность\s*\n/, "");
      const splitMarkers = [
        "\nРазвернуть\n",
        "\nДополнительные характеристики\n",
      ];
      for (const marker of splitMarkers) {
        const idx = ingredients.indexOf(marker);
        if (idx !== -1) ingredients = ingredients.substring(0, idx);
      }
      ingredients = ingredients.replace(/\n{2,}/g, "\n").trim();
      const lines = ingredients.split("\n").filter((l) => l.trim());
      let ingrText = "";
      for (const line of lines) {
        if (
          line.length > 30 &&
          !line.match(
            /ккал|Энергетическая|Пищевая|белки|жиры|углеводы|Развернуть/i
          )
        ) {
          ingrText = line.trim();
          break;
        }
      }
      if (!ingrText) ingrText = ingredients;
      const imgEl = document.querySelector(".swiper-slide__img");
      let imgUrl = "";
      if (imgEl) {
        const src = imgEl.getAttribute("src");
        if (src)
          imgUrl = src.startsWith("http") ? src : `https://msk.palich.ru${src}`;
      }
      return { description, ingredients: ingrText, imgUrl };
    });
  } catch (e) {
    return { description: "", ingredients: "", imgUrl: "" };
  }
}

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    userAgent:
      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
  });
  const page = await context.newPage();

  const results = [];
  for (let i = 0; i < PRODUCTS.length; i++) {
    const p = PRODUCTS[i];
    const detailUrl = `https://msk.palich.ru${p.url}`;
    const detail = await extractDetail(page, detailUrl);
    console.error(
      `${i + 1}. ${p.name}: desc=${detail.description.substring(0, 60)}... img=${detail.imgUrl.substring(0, 60)}...`
    );
    results.push({
      name: p.name,
      imgUrl: detail.imgUrl,
      weight: p.weight,
      description: detail.description,
      ingredients: detail.ingredients,
    });
  }

  await browser.close();
  console.log(JSON.stringify(results, null, 2));
})();
