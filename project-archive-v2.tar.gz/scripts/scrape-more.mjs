import { chromium } from "playwright";

const EXISTING = [
  "Прага пирожные-канапе 700 г",
  "Корзиночка пирожные 280 г",
  "Малиновое пирожные-канапе 900 г",
  "Наполеон оригинальное пирожные-канапе 650 г",
  "Корзиночка Оригинальная пирожные 280 г",
  "Чизкейк с ягодами пирожные 310 г",
  "Донат с карамельным шоколадом и ванильной начинкой 30 г",
  "Снежная малина пирожные 185 г",
  "Киевское оригинальное пирожные-канапе 450 г",
  "Прага оригинальная пирожные-канапе 700 г",
  "Солнечные ягоды пирожные 200 г",
  "Профитроли с пломбиром пирожные 250 г",
  "Медовое пирожные-канапе 550 г",
  "Шоколадные меренги оригинальные 180 г",
];

function cleanName(title) {
  return title
    .replace(/ от Палыча с доставкой на дом$/, "")
    .replace(/ от Палыча с доставкой$/, "")
    .replace(/ с доставкой на дом$/, "")
    .replace(/к Дню семьи, любви и верности /g, "")
    .replace(/к Дню семьи, любви и верности$/g, "")
    .trim();
}

async function scrape(browser, url) {
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: "networkidle", timeout: 30000 });
  const title = cleanName(await page.title());
  const images = await page.evaluate(() => {
    const imgs = document.querySelectorAll(".swiper-slide__img");
    return imgs.length > 0 ? imgs[0].src : "";
  });
  const description = await page.evaluate(() => {
    const h2s = document.querySelectorAll("h2");
    for (const h2 of h2s) {
      if (h2.textContent.includes("Описание")) {
        let el = h2.nextElementSibling;
        while (el) {
          const text = el.textContent.trim();
          if (text && text !== "Описание товара")
            return text.replace(/\s+/g, " ").trim();
          el = el.nextElementSibling;
        }
      }
    }
    return "";
  });
  const ingredientsFull = await page.evaluate(() => {
    const h3s = document.querySelectorAll("h3");
    for (const h3 of h3s) {
      if (h3.textContent.includes("Состав")) {
        let el = h3.nextElementSibling;
        let texts = [];
        while (el && el.tagName !== "H3" && el.tagName !== "H2") {
          const txt = el.textContent.trim();
          if (txt) texts.push(txt);
          el = el.nextElementSibling;
        }
        return texts.join(" ").replace(/\s+/g, " ").trim();
      }
    }
    return "";
  });
  let ingredients = ingredientsFull;
  const nutritionMatch = ingredientsFull.match(/белки[\s\S]{0,200}кДж\./i);
  if (nutritionMatch) {
    ingredients = ingredientsFull
      .substring(nutritionMatch.index + nutritionMatch[0].length)
      .trim();
  }
  ingredients = ingredients
    .replace(/\n/g, " ")
    .replace(/\s+/g, " ")
    .replace(/^[^А-ЯA-Z]+/, "")
    .replace(/Произведено[\s\S]*$/, "")
    .replace(/Развернуть.*$/, "")
    .trim()
    .replace(/,\s*$/, "")
    .trim();
  const weightMatch = title.match(/(\d+)\s*г/);
  const weight = weightMatch ? weightMatch[0] : "";
  await page.close();
  return { title, weight, description, ingredients, image: images };
}

async function getPastryLinks(browser, url) {
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: "networkidle", timeout: 30000 });
  const links = await page.evaluate(() => {
    const items = document.querySelectorAll(
      '[class*="product-card"] a, a[href*="/catalog/pirozhnye_i_deserty/"]'
    );
    const seen = new Set();
    const result = [];
    items.forEach((a) => {
      const h = a.href;
      if (
        h &&
        h.includes("/catalog/pirozhnye_i_deserty/") &&
        h.match(/\d+\//) &&
        !seen.has(h)
      ) {
        seen.add(h);
        result.push(h);
      }
    });
    return result;
  });
  await page.close();
  return [...new Set(links)];
}

async function main() {
  const browser = await chromium.launch({ headless: true });
  const moreUrls = ["?PAGEN_1=3", "?PAGEN_1=4", "?PAGEN_1=5"];
  const allLinks = [];
  for (const p of moreUrls) {
    const url = `https://msk.palich.ru/catalog/pirozhnye_i_deserty/${p}`;
    const links = await getPastryLinks(browser, url);
    allLinks.push(...links);
    console.error(`Found ${links.length} from ${p}`);
  }
  const unique = [...new Set(allLinks)];
  console.error(`Total unique links: ${unique.length}`);

  const results = [];
  for (const url of unique) {
    try {
      const data = await scrape(browser, url);
      const isExisting = EXISTING.some((n) =>
        data.title.toLowerCase().includes(
          n
            .toLowerCase()
            .replace(/[^а-яa-z0-9\s]/g, "")
            .trim()
        )
      );
      if (!isExisting) {
        results.push(data);
        console.error(`[NEW] ${data.title}`);
        if (results.length >= 4) break;
      } else {
        console.error(`[SKIP] ${data.title}`);
      }
    } catch (e) {
      console.error(`[ERR] ${url}: ${e.message}`);
    }
  }

  console.log(JSON.stringify(results, null, 2));
  await browser.close();
}

main().catch(console.error);
