// Error interception disabled — see task-059.
// All error reporting through the bridge has been removed.
