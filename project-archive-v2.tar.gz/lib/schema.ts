import {
  type KeySchemaElement,
  type AttributeDefinition,
  type GlobalSecondaryIndex,
} from "@aws-sdk/client-dynamodb";

export const TableName = {
  SERVICES: "services",
} as const;

export type TableName = (typeof TableName)[keyof typeof TableName];

export interface TableSchema {
  name: TableName;
  keySchema: KeySchemaElement[];
  attributeDefinitions: AttributeDefinition[];
  globalSecondaryIndexes?: GlobalSecondaryIndex[];
}

export const TABLE_SCHEMAS: Record<TableName, TableSchema> = {
  [TableName.SERVICES]: {
    name: TableName.SERVICES,
    keySchema: [{ AttributeName: "id", KeyType: "HASH" }],
    attributeDefinitions: [
      { AttributeName: "id", AttributeType: "S" },
      { AttributeName: "status", AttributeType: "S" },
    ],
    globalSecondaryIndexes: [
      {
        IndexName: "status-index",
        KeySchema: [{ AttributeName: "status", KeyType: "HASH" }],
        Projection: { ProjectionType: "ALL" },
      },
    ],
  },
};

export const TABLE_NAMES: TableName[] = Object.values(TableName);

export const IndexName = {
  SERVICES_STATUS: "status-index",
} as const;

export type IndexName = (typeof IndexName)[keyof typeof IndexName];

// --- Catalog domain types ---

export type ProductCategory =
  "cakes" | "pastries" | "pies" | "sausages" | "ice-cream" | "frozen";

export interface Product {
  id: string;
  name: string;
  photo: string;
  description: string;
  ingredients: string;
  weight: string;
  category: ProductCategory;
}

export interface Store {
  id: string;
  name: string;
  address: string;
  phone: string;
  hours: string;
  lat: number;
  lng: number;
}

export const CATEGORY_LABELS: Record<ProductCategory, string> = {
  cakes: "Торты",
  pastries: "Пирожные",
  pies: "Пироги",
  sausages: "Колбаса и деликатесы",
  "ice-cream": "Мороженое",
  frozen: "Заморозка",
};

export const CATEGORIES: ProductCategory[] = [
  "cakes",
  "pastries",
  "pies",
  "sausages",
  "ice-cream",
  "frozen",
];
