const STORAGE_KEY = "favorites";

export function getFavoriteIds(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return [];
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function setFavoriteIds(ids: string[]): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
  window.dispatchEvent(new CustomEvent("favorites-changed", { detail: ids }));
}

export function toggleFavoriteId(id: string): boolean {
  const ids = getFavoriteIds();
  const index = ids.indexOf(id);
  if (index === -1) {
    setFavoriteIds([...ids, id]);
    return true;
  } else {
    setFavoriteIds(ids.filter((i) => i !== id));
    return false;
  }
}
